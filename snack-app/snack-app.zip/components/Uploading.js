import {
    Image, 
    Text,
    StyleSheet,
    View,
    Button,
    TouchableOpacity,
} from "react-native";
import {BlurView, VibrancyView} from "@react-native-community/blur"
import ProgressBar from "./ProgressBar";

export  function Uploading ({image, video, progress}){
    return(
        <View>
            <VibrancyView>
                
            </VibrancyView>
        </View>
    )
}