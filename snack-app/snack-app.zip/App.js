import { StyleSheet, Text, View, Image } from 'react-native';
import Splash from './screens/Splash';
import Login from './screens/Login';
import Register from './screens/Register';

export default function App() {
  return (
     //<Splash></Splash>
     //<Login></Login>
     <Register></Register>
  );
}
